# Chmod KYC Web SDK

Identity verification in the browser: document capture and face liveness (Amazon Rekognition Face
Liveness) inside any web page. It is the web version of [`sdk-mobile`](https://github.com/ChmodLab/sdk-mobile)
and uses the same backend, configuration (`SdkConfig`) and result (`VerificationResult`).

## Install

Releases are public in [`chmod-kyc-sdk-web`](https://github.com/ChmodLab/chmod-kyc-sdk-web), with no account or token:

```bash
npm install https://github.com/ChmodLab/chmod-kyc-sdk-web/releases/download/kyc-web-v1.0.0/chmodlab-kyc-web-1.0.0.tgz
```

## Usage

```js
import { startVerification } from '@chmodlab/kyc-web';
import '@chmodlab/kyc-web/style.css';

const handle = startVerification({
  container: '#kyc',          // element or selector; the SDK fills it
  baseUrl: 'https://<api-id>.execute-api.us-east-1.amazonaws.com',
  sdkToken,                   // created by YOUR backend with the transaction, never in the browser
  sdkConfig: { locale: { defaultLanguage: 'en' } },
  onResult: (result) => {     // { type: 'Completed' | 'Cancelled' | 'Failed', transactionId, code, message }
    handle.destroy();
  },
});
```

Without a bundler, load `chmod-kyc.iife.js` and `chmod-kyc.css` from the same release (or from
`kyc-web/<version>/` in that repo) and call `window.ChmodKyc.startVerification`.

- React and everything else is bundled in: it works on any page, with no peer dependencies.
- Browser only: in Next.js, load it on the client (`dynamic(..., { ssr: false })`).
- The page must be served over HTTPS (or `localhost`) for the camera to work.

### Full-screen container on phones

The SDK fills its container and scrolls inside it. To use the visible area of the browser, between
its bars:

```css
#kyc { position: fixed; top: 0; left: 0; right: 0; height: 100dvh; }
html, body { height: 100%; overflow: hidden; }
```

Don't use `requestFullscreen`: iPhone doesn't support it for pages, and on Android it hides the bars.

## Phones and tablets only

The verification runs only in a phone or tablet browser (iOS, iPadOS, Android). On a computer the SDK
asks for nothing, shows "Open this link on your phone" and ends with `Failed` / `DESKTOP_NOT_SUPPORTED`.
The `sdkToken` can still be used from a phone. To try it on a computer, use the browser's device mode.

## Flow

Permissions (camera, and location per `locationPermission`) → session → welcome and terms →
document front and back → upload → liveness → result. Same steps and order as mobile.

## Differences from mobile

- **Document capture** is always manual, with the shutter button. Uploading a photo is not allowed.
- **Device metadata** leaves out what a browser can't know (emulator, root, developer mode), and
  `device_id` is random per verification.
- **Liveness** offers up to 3 attempts, each with a new Rekognition session.
- **Reloading the page** starts a new session on the same transaction.

## Content Security Policy

If your page has a CSP, the SDK needs:

- `script-src 'wasm-unsafe-eval'` and `worker-src blob:`
- `connect-src`: the Chmod API, `https://*.amazonaws.com`, `wss://streaming-rekognition.us-east-1.amazonaws.com`
  and `https://cdn.liveness.rekognition.amazonaws.com`
- `img-src blob: data:`, `media-src blob:` and `style-src 'unsafe-inline'`

The SDK's CSS is scoped to `.ck-root`, so it doesn't change your page's styles.

## Development

```bash
npm install      # the liveness fork comes from vendor/
npm run build    # dist/: ESM, CJS, <script> build, CSS and types
```

To test it on a phone, use `web-app` in `sdk-mobile-test` (`./update-sdk.sh` builds this checkout).

The liveness fork is the `.tgz` [`sdk-web-liveness`](https://github.com/ChmodLab/sdk-web-liveness) publishes in
`chmod-kyc-sdk-web/kyc-liveness-web/<version>/`, kept in `vendor/`. To update it, put the new `.tgz` there and
run `npm i -D ./vendor/<file>`.

## Publishing

*Actions* → *Publish* → *Run workflow*, from `main`, publishes the version in `package.json` to the public
[`chmod-kyc-sdk-web`](https://github.com/ChmodLab/chmod-kyc-sdk-web) repo: the `.tgz`, `chmod-kyc.iife.js` and
`chmod-kyc.css` in `kyc-web/<version>/` and in the `kyc-web-v<version>` release. It needs the `CHMOD_DIST_PAT`
secret, never replaces a published version, and requires the bundled liveness version to be published first.

## License

Proprietary: Chmod Proprietary License 1.0, see [LICENSE](LICENSE). Only Chmod customers with a current
agreement may use the SDK. Copying, modifying, redistributing or reselling it requires Chmod's written
permission.
