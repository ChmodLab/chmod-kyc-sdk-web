# Chmod Liveness Web

Chmod's fork of the **Face Liveness** component from [Amplify UI](https://github.com/aws-amplify/amplify-ui)
(`packages/react-liveness`, v3.7.0, commit `2a850f7`). [`sdk-web`](https://github.com/ChmodLab/sdk-web)
uses it for the liveness step with [Amazon Rekognition Face Liveness](https://aws.amazon.com/rekognition/face-liveness/).
It is the web counterpart of [`sdk-mobile-liveness-android`](https://github.com/ChmodLab/sdk-mobile-liveness-android)
and [`sdk-mobile-liveness-ios`](https://github.com/ChmodLab/sdk-mobile-liveness-ios).

Only that package was copied: `aws-amplify` and `@aws-amplify/core` stay as peer dependencies.

## Changes from upstream

- **Mobile look:** full-screen camera on black, with the same fixed oval as the mobile forks. The oval
  border matches iOS and stays sharp on high-density screens.
- **Freshness colors** cover the whole screen and are translucent, as on mobile.
- **No jumps on open:** the camera shows once its frame size settles, together with the oval.
- **Instructions** as a pill above the oval, the match bar below it, and a close button before recording.
- **Spanish and Portuguese texts** (`livenessDisplayTextEs`, `livenessDisplayTextPt`,
  `livenessDisplayTextByLanguage`). English is still the default.
- **Theming** through the CSS variables listed in `src/chmod/chmod.css`, such as
  `--chmod-liveness-oval-background` for the area around the oval (white by default, as upstream).
- **Standalone build**, outside the Amplify monorepo.

The liveness logic (state machine, streaming to Rekognition, face detection) is unchanged.

## Usage

```tsx
import { FaceLivenessDetectorCore, livenessDisplayTextEs } from '@chmodlab/kyc-liveness-web';
import '@chmodlab/kyc-liveness-web/styles.css';

<FaceLivenessDetectorCore
  sessionId={rekognitionSessionToken}   // from POST /session/liveness
  region="us-east-1"
  displayText={livenessDisplayTextEs}
  config={{ credentialProvider: async () => ({ accessKeyId, secretAccessKey, sessionToken }) }}
  onAnalysisComplete={async () => { /* POST /session/complete-liveness */ }}
  onError={(error) => { /* ... */ }}
/>
```

The credentials are the temporary ones returned by `POST /session/liveness`. No Amplify or Cognito
setup is needed.

## Development

```bash
npm install                 # uses legacy-peer-deps (.npmrc)
npx patch-package           # patches @tensorflow-models/face-detection (prebuild does it too)
npx jest --coverage=false
npm run build
```

## Publishing

*Actions* → *Publish* → *Run workflow*, from `main`, publishes the version in `package.json` to the public
[`chmod-kyc-sdk-web`](https://github.com/ChmodLab/chmod-kyc-sdk-web) repo: the `.tgz` in
`kyc-liveness-web/<version>/` and in the `kyc-liveness-web-v<version>` release. It needs the `CHMOD_DIST_PAT`
secret and never replaces a published version. Publish here before `sdk-web` releases a version that bundles it.

## Updating from upstream

1. Diff `packages/react-liveness/src` in `aws-amplify/amplify-ui` between the base commit and the new one.
2. Apply that diff here, run the tests, and record the new commit in `NOTICE` and in this README.

## License

Derived from `aws-amplify/amplify-ui`, under the Apache License 2.0. See [LICENSE](LICENSE) and [NOTICE](NOTICE).
